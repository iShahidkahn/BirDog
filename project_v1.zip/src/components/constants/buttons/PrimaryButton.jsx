import React from "react";

const PrimaryButton = (props) => {
  return <div className="primary_btn ">{props.primaryBtn}</div>;
};

export default PrimaryButton;
